#!/bin/bash

echo "⠿⠿ Install Additional Packages ..."
sudo apt-get update -y
sudo apt-get install -y git tree nano sshpass lsof net-tools
