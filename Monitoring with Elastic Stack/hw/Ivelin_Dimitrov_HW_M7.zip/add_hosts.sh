#!/bin/bash

echo "⠿⠿ Adding hosts..."
echo "192.168.56.11 centos.m7.se server" >> /etc/hosts
echo "192.168.56.12 centos.m7.fc ccentos" >> /etc/hosts
echo "192.168.56.13 ubuntu.m7.sc cubuntu" >> /etc/hosts
