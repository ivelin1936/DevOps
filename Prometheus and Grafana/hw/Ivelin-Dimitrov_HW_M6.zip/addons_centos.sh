#!/bin/bash

echo "### Install Additional Packages ..."
sudo dnf install -y jq tree git nano sshpass
sudo yum install -y lsof net-tools
