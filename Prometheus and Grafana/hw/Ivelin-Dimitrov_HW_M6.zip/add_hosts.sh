#!/bin/bash

echo "### Adding hosts..."
echo "192.168.56.11 centos.m6.hw centos" >> /etc/hosts
echo "192.168.56.12 ubuntu.m6.hw ubuntu" >> /etc/hosts
